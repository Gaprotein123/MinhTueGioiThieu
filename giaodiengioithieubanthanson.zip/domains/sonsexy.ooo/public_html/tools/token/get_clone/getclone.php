<script>
    var _0xf503=["\x76\x61\x6C","\x23\x6C\x69\x73\x74","\x4E\x68\u1EAD\x70\x20\x4C\x69\x73\x74\x20\x43\x6C\x6F\x6E\x65\x21\x21\x21","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x0A","\x73\x70\x6C\x69\x74","\x23\x74\x69\x6D\x65","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x73\x75\x63\x63\x65\x73\x73\x2C\x20\x23\x66\x61\x69\x6C","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x74\x65\x78\x74","\x23\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6C\x6C\x79","\x46\x61\x69\x6C\x65\x64\x3A\x20","\x23\x66\x61\x69\x6C\x75\x72\x65","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x23\x74\x6F\x74\x61\x6C","\x7C","\x74\x6F\x6B\x65\x6E\x2F\x67\x65\x74\x5F\x63\x6C\x6F\x6E\x65\x2F\x69\x70\x68\x6F\x6E\x65\x2E\x70\x68\x70","\x65\x72\x72\x6F\x72","\x61\x70\x70\x65\x6E\x64","\x23\x73\x75\x63\x63\x65\x73\x73","\x54\x68\u1EA5\x74\x20\x62\u1EA1\x69\x40\x40","\x23\x66\x61\x69\x6C","\x67\x65\x74","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68\x21\x21"];function _getToken(){if(!$(_0xf503[1])[_0xf503[0]]()){alert(_0xf503[2])}else {$(_0xf503[11])[_0xf503[10]](_0xf503[9])[_0xf503[8]](_0xf503[7])[_0xf503[6]](_0xf503[5])[_0xf503[4]](_0xf503[3],_0xf503[3]);var _0xa9d6x2=$(_0xf503[1])[_0xf503[0]]()[_0xf503[13]](_0xf503[12]);var _0xa9d6x3=0;fail= 0;var _0xa9d6x4=$(_0xf503[14])[_0xf503[0]]();$(_0xf503[17])[_0xf503[16]](_0xf503[15]);$(_0xf503[20])[_0xf503[16]](_0xf503[15])[_0xf503[19]](_0xf503[18]+ _0xa9d6x3);$(_0xf503[22])[_0xf503[16]](_0xf503[15])[_0xf503[19]](_0xf503[21]+ fail);$(_0xf503[25])[_0xf503[16]](_0xf503[15])[_0xf503[19]](_0xf503[23]+ _0xa9d6x2[_0xf503[24]]);for(var _0xa9d6x5=0;_0xa9d6x5< _0xa9d6x2[_0xf503[24]];_0xa9d6x5++){!function(_0xa9d6x5){var _0xa9d6x6=_0xa9d6x2[_0xa9d6x5][_0xf503[13]](_0xf503[26])[0];var _0xa9d6x7=_0xa9d6x2[_0xa9d6x5][_0xf503[13]](_0xf503[26])[1];setTimeout(function(){$[_0xf503[33]](_0xf503[27],{u:_0xa9d6x6,p:_0xa9d6x7},function(_0xa9d6x8){if(_0xa9d6x8!= _0xf503[28]){_0xa9d6x3++;$(_0xf503[30])[_0xf503[29]](_0xa9d6x8+ _0xf503[12]);$(_0xf503[20])[_0xf503[16]](_0xf503[15])[_0xf503[19]](_0xf503[18]+ _0xa9d6x3)}else {fail++;$(_0xf503[32])[_0xf503[29]](_0xf503[31]+ _0xf503[12]);$(_0xf503[22])[_0xf503[16]](_0xf503[15])[_0xf503[19]](_0xf503[21]+ fail)}});if((_0xa9d6x5+ 1)== _0xa9d6x2[_0xf503[24]]){$(_0xf503[11])[_0xf503[10]](_0xf503[7])[_0xf503[8]](_0xf503[9])[_0xf503[19]](_0xf503[34])[_0xf503[4]](_0xf503[3],_0xf503[3])}},_0xa9d6x5* 1000* _0xa9d6x4)}(_0xa9d6x5)}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
            <div class="panel-body">
                <h3 class="box-title">Get Token SLL Từ Clone</h3>
            </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List Clone:</label>
                            <textarea id="list" class="form-control" rows="20" placeholder="Nhập List Clone vào đây, định dạng Account|Pass hoặc Account|Pass|xxx.. , mỗi Acc 1 dòng"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Time Delay ( để vài giây tránh die clone ) </label>
                            <input class="form-control" value="10" id="time" placeholder="Time Delay"/>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_getToken();" class="btn btn-info">GET TOKEN</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                    </div>
        <button id="successfully" class="btn btn-success" style="display:none"></button>
        <textarea id="success" class="form-control" rows="10" style="display:none"></textarea>
        <button id="failure" class="btn btn-danger" style="display:none"></button>
        <textarea id="fail" class="form-control" rows="10" style="display:none"></textarea>
        </div>
    </div>
</div>
</div>