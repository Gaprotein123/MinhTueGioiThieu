<script>
    var _0x64ed=["\x76\x61\x6C","\x23\x74\x79\x70\x65","\x23\x74\x69\x6D\x65","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x23\x74\x6F\x6B\x65\x6E","\x23\x6C\x69\x6D\x69\x74","\x54\x6F\x74\x61\x6C\x3A\x20","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x46\x61\x69\x6C\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F\x6D\x65\x2F\x61\x63\x63\x6F\x75\x6E\x74\x73\x3F\x66\x69\x65\x6C\x64\x73\x3D\x69\x64\x2C\x6E\x61\x6D\x65\x2C\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x26\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x6D\x65\x74\x68\x6F\x64\x3D\x67\x65\x74\x26\x6C\x69\x6D\x69\x74\x3D","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x74\x6F\x6B\x65\x6E","\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E","\x64\x61\x74\x61","\x0A","\x61\x70\x70\x65\x6E\x64","\x23\x72\x65\x73\x75\x6C\x74","\x69\x64\x74\x6F\x6B\x65\x6E","\x69\x64","\x7C","\x69\x64\x6E\x61\x6D\x65\x74\x6F\x6B\x65\x6E","\x6E\x61\x6D\x65","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _getPage(){if(!$(_0x64ed[1])[_0x64ed[0]]()||  !$(_0x64ed[2])[_0x64ed[0]]()){alert(_0x64ed[3])}else {$(_0x64ed[12])[_0x64ed[11]](_0x64ed[10])[_0x64ed[9]](_0x64ed[8])[_0x64ed[7]](_0x64ed[6])[_0x64ed[5]](_0x64ed[4],_0x64ed[4]);var _0x2396x2=$(_0x64ed[13])[_0x64ed[0]]();var _0x2396x3=$(_0x64ed[2])[_0x64ed[0]]();var _0x2396x4=$(_0x64ed[1])[_0x64ed[0]]();var _0x2396x5=$(_0x64ed[14])[_0x64ed[0]]();var _0x2396x6=0;fail= 0;$(_0x64ed[19])[_0x64ed[18]](_0x64ed[17])[_0x64ed[16]](_0x64ed[15]+ _0x2396x5);for(var _0x2396x7=0;_0x2396x7< _0x2396x5;_0x2396x7++){!function(_0x2396x7){setTimeout(function(){$[_0x64ed[38]](_0x64ed[23]+ _0x2396x2+ _0x64ed[24]+ _0x2396x5,function(_0x2396x8){_0x2396x6++;$(_0x64ed[26])[_0x64ed[18]](_0x64ed[17])[_0x64ed[16]](_0x64ed[25]+ _0x2396x6);if(_0x2396x4== _0x64ed[27]){$(_0x64ed[32])[_0x64ed[18]](_0x64ed[17])[_0x64ed[31]](_0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[28]]+ _0x64ed[30])}else {if(_0x2396x4== _0x64ed[33]){$(_0x64ed[32])[_0x64ed[18]](_0x64ed[17])[_0x64ed[31]](_0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[34]]+ _0x64ed[35]+ _0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[28]]+ _0x64ed[30])}else {if(_0x2396x4== _0x64ed[36]){$(_0x64ed[32])[_0x64ed[18]](_0x64ed[17])[_0x64ed[31]](_0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[34]]+ _0x64ed[35]+ _0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[37]]+ _0x64ed[35]+ _0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[28]]+ _0x64ed[30])}else {$(_0x64ed[32])[_0x64ed[18]](_0x64ed[17])[_0x64ed[31]](_0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[37]]+ _0x64ed[35]+ _0x2396x8[_0x64ed[29]][_0x2396x7][_0x64ed[28]]+ _0x64ed[30])}}}})[_0x64ed[22]](function(){fail++;$(_0x64ed[21])[_0x64ed[18]](_0x64ed[17])[_0x64ed[16]](_0x64ed[20]+ fail)});if((_0x2396x7+ 1)== _0x2396x5){$(_0x64ed[12])[_0x64ed[11]](_0x64ed[8])[_0x64ed[9]](_0x64ed[10])[_0x64ed[16]](_0x64ed[39])[_0x64ed[5]](_0x64ed[4],_0x64ed[4])}},_0x2396x7* 1000* _0x2396x3)}(_0x2396x7)}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
            <div class="panel-body">
                <h3 class="box-title">Auto GET Token FanPage</h3>
            </div>
            <div class="box-body">
            <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Token acc cần get (không dùng token clone): </label>
                            <input type="text" placeholder="Nhập token vào đây" class="form-control" name="token" id="token" />
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Chọn định dạng xuất:</label>
                            <select name="type" id="type" class="form-control">
                                <option value="token">Chỉ token</option>
                                <option value="idtoken">PageID|Token</option>
                                <option value="idnametoken">PageID|Name|Token</option>
                                <option value="nametoken">Name|Token</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập số lượng page: </label>
                            <input class="form-control" id="limit" placeholder="Số lương page cần get"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Time Delay(tính bằng giây, 0.1 tức là 1/10 giây) </label>
                            <input class="form-control" id="time" placeholder="Time Delay"/>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_getPage();" class="btn btn-info">Get Token Page</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
                    <textarea id="result" style="display:none" class="form-control" rows="20"></textarea>
                    
                   </div> 
        </div>
    </div>
</div>
