        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div 
   <ul class="breadcrumb">
        <li>
            <a href="#">Home</a>
        </li>
        <li>
            <a href="#">Dashboard</a>
        </li>
    </ul>
</div>
<div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well">
                <h2><i class="glyphicon glyphicon-info-sign"></i> Giới thiệu hệ thống</h2>

                <div class="box-icon">
                    <a href="#" class="btn btn-minimize btn-round btn-default"><i
                            class="glyphicon glyphicon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round btn-default"><i
                            class="glyphicon glyphicon-remove"></i></a>
                </div>
            </div>
            <div class="box-content row">
                <div class="col-lg-7 col-md-12">
                    <h1>TuongTac.Biz<br>
                        <small>Hệ thống tools miễn phí</small>
                    </h1>
                    <p>Danh sách các chức năng : Check live token, Check live UID, Get token, Đếm tin nhắn,...</p>

                    <p><b>Hoàn toàn free và không lưu token khi sử dụng.</b></p>

                </div>
                <!-- Ads, you can remove these -->
        <div class="box col-md-4">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">
                <h2><i class="glyphicon glyphicon-user"></i> ADMIN</h2>

                <div class="box-icon">
                    <a href="#" class="btn btn-minimize btn-round btn-default"><i
                            class="glyphicon glyphicon-chevron-down"></i></a>
                    <a href="#" class="btn btn-close btn-round btn-default"><i
                            class="glyphicon glyphicon-remove"></i></a>
                </div>
            </div>
            <div class="box-content" style="display: none;">
                <div class="box-content">
                    <ul class="dashboard-list">
                        <li>
                            <a href="#">
                                <img class="dashboard-avatar" alt="Usman"
                                     src="https://graph.fb.me/100005783588959/picture?weidh=500&height=500"></a>
                            <strong>Tên:</strong> <a href="//fb.com/100005783588959">Nguyễn Thanh Sơn
                            </a><br>
                            <strong>Ngày thành lập:</strong> 20/10/2018<br>
                            <strong>Trạng Thái:</strong> <span class="label-success label label-default">Hoạt Động</span>
                        </li>
                    </div>
                <!-- Ads end -->
                           </div>
                        </div>
                     </div>
                   </div>
                </div>
            </div>
        </div>
    </div>
</div>
