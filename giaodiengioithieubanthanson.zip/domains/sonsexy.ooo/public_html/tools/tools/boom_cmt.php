<script>
    var _0x35ab=["\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x20\x73\x74\x79\x6C\x65\x3D\x22\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x31\x32\x70\x78\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x61\x64\x64\x43\x6C\x61\x73\x73","\x23\x65\x78\x65\x63","\x7C","\x73\x70\x6C\x69\x74","\x76\x61\x6C","\x23\x6E\x6F\x69\x5F\x64\x75\x6E\x67","\x23\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E","\x23\x70\x6F\x73\x74\x69\x64","\x23\x74\x69\x6D\x65","\x23\x6C\x69\x6D\x69\x74","\x54\x6F\x74\x61\x6C\x3A\x20","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x72\x61\x6E\x64\x6F\x6D","\x6C\x65\x6E\x67\x74\x68","\x66\x6C\x6F\x6F\x72","\x46\x61\x69\x6C\x65\x64\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x64\x6F\x6E\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x2F\x63\x6F\x6D\x6D\x65\x6E\x74\x73\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x6D\x65\x73\x73\x61\x67\x65\x3D","\x26\x6D\x65\x74\x68\x6F\x64\x3D\x70\x6F\x73\x74","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68\x21","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x70\x72\x69\x6D\x61\x72\x79","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73"];function exec(){$(_0x35ab[6])[_0x35ab[5]](_0x35ab[4])[_0x35ab[3]](_0x35ab[2])[_0x35ab[1]](_0x35ab[0],_0x35ab[0]);var _0x1072x2=$(_0x35ab[10])[_0x35ab[9]]()[_0x35ab[8]](_0x35ab[7]);var _0x1072x3=$(_0x35ab[11])[_0x35ab[9]]();var _0x1072x4=$(_0x35ab[12])[_0x35ab[9]]();var _0x1072x5=$(_0x35ab[13])[_0x35ab[9]]();var _0x1072x6=$(_0x35ab[14])[_0x35ab[9]]();var _0x1072x7=0,_0x1072x8=0;$(_0x35ab[19])[_0x35ab[18]](_0x35ab[17])[_0x35ab[16]](_0x35ab[15]+ _0x1072x6);for(var _0x1072x9=0;_0x1072x9< _0x1072x6;_0x1072x9++){!function(_0x1072x9){setTimeout(function(){var _0x1072xa=_0x1072x2[Math[_0x35ab[22]](Math[_0x35ab[20]]()* _0x1072x2[_0x35ab[21]])];$[_0x35ab[33]](_0x35ab[29]+ _0x1072x4+ _0x35ab[30]+ _0x1072x3+ _0x35ab[31]+ encodeURIComponent(_0x1072xa)+ _0x35ab[32])[_0x35ab[28]](function(){_0x1072x7++;$(_0x35ab[27])[_0x35ab[18]](_0x35ab[17])[_0x35ab[16]](_0x35ab[26]+ _0x1072x7)})[_0x35ab[25]](function(){_0x1072x8++;$(_0x35ab[24])[_0x35ab[18]](_0x35ab[17])[_0x35ab[16]](_0x35ab[23]+ _0x1072x8)});if((_0x1072x9+ 1)== _0x1072x6){$(_0x35ab[6])[_0x35ab[36]](_0x35ab[4])[_0x35ab[5]](_0x35ab[35])[_0x35ab[16]](_0x35ab[34])[_0x35ab[1]](_0x35ab[0],_0x35ab[0])}},_0x1072x9* 1000* _0x1072x5)}(_0x1072x9)}}
</script>
<div id="result"></div>
<div class="col-md-10" id="form">
            <div class="panel-body">
              <h3>Auto Bão CMT Status (nhiều nội dung khác nhau thì cách nhau bởi dấu Gạch Thẳng "<font color="red">|</font>")</h3>
            </div>
                <div class="form-group">
                        <div class="form-group">
                            <label>Nhập Token Full Quyền: </label>
                            <input type="text" placeholder="Nhập token vào đây" class="form-control" name="access_token" id="access_token" />
                        </div>
                    </div>
              <div class="box-body">
                <div class="form-group">
                  <label for="id">Nhập Post ID Muốn Bão CMT:</label>
                      <input type="text" class="form-control" name="postid" id="postid" placeholder="Nhập POST ID" required="">
                </div>
                   <div class="form-group">
                  <label for="sl">Số lượng:</label>
                  <input type="number" class="form-control" name="so_luong" id="limit" placeholder="Nhập số lượng" required="">
                </div>
                 <div class="form-group">
                  <label for="nd">Nội dung (nhiều nội dung khác nhau thì cách nhau bởi dấu Gạch Thẳng "<font color="red">|</font>"):</label>
                  <textarea class="form-control" rows="5" name="noi_dung" id="noi_dung" placeholder="Nội dung 1 | Nội dung 2 | ... | ..." required></textarea>
                </div>
                <div class="form-group">
                    <label for="time"> Delay (tính bằng giây):</label><br />
                    <input type="text" name="time" id="time" class="form-control" placeholder="Nhập Time Delay" />
                </div>
              </div>

              <div class="box-footer">
                <button type="button" class="btn btn-primary" id="exec" onclick="exec();">Auto Bão CMT</button>
                <button id="total" class="btn btn-default" style="display:none"></button>
                <button id="success" class="btn btn-success" style="display:none"></button>
                <button id="fail" class="btn btn-danger"style="display:none"></button>
              </div>
          </div>
</div>
