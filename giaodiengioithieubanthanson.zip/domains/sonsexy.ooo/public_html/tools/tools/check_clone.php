<script>
    var _0x2de7=["\x76\x61\x6C","\x23\x63\x6C\x6F\x6E\x65","\x23\x74\x6F\x6B\x65\x6E","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67\x20\x74\x69\x6E","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x74\x72\x69\x6D","\x23\x74\x79\x70\x65","\x0A","\x73\x70\x6C\x69\x74","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x3D","\x3B","\x44\x69\x65\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x66\x69\x65\x6C\x64\x73\x3D\x69\x64\x26\x6D\x65\x74\x68\x6F\x64\x3D\x67\x65\x74","\x4C\x69\x76\x65\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x6F\x6E\x6C\x79\x5F\x69\x64","\x61\x70\x70\x65\x6E\x64","\x23\x6C\x69\x76\x65","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _checkLive(){if(!$(_0x2de7[1])[_0x2de7[0]]()||  !$(_0x2de7[2])[_0x2de7[0]]()){alert(_0x2de7[3])}else {$(_0x2de7[12])[_0x2de7[11]](_0x2de7[10])[_0x2de7[9]](_0x2de7[8])[_0x2de7[7]](_0x2de7[6])[_0x2de7[5]](_0x2de7[4],_0x2de7[4]);var _0xd0d9x2=$(_0x2de7[2])[_0x2de7[0]]()[_0x2de7[13]]();var _0xd0d9x3=$(_0x2de7[14])[_0x2de7[0]]()[_0x2de7[13]]();var _0xd0d9x4=0;fail= 0;var _0xd0d9x5=$(_0x2de7[1])[_0x2de7[0]]()[_0x2de7[16]](_0x2de7[15]);$(_0x2de7[22])[_0x2de7[21]](_0x2de7[20])[_0x2de7[19]](_0x2de7[17]+ _0xd0d9x5[_0x2de7[18]]);for(let _0xd0d9x6=0;_0xd0d9x6< _0xd0d9x5[_0x2de7[18]];_0xd0d9x6++){var _0xd0d9x7=_0xd0d9x5[_0xd0d9x6][_0x2de7[16]](_0x2de7[23]);var _0xd0d9x8=_0xd0d9x7[1][_0x2de7[16]](_0x2de7[24]);var _0xd0d9x9=_0xd0d9x8[0];$[_0x2de7[36]](_0x2de7[28]+ _0xd0d9x9+ _0x2de7[29]+ _0xd0d9x2+ _0x2de7[30],function(_0xd0d9xa){_0xd0d9x4++;$(_0x2de7[32])[_0x2de7[21]](_0x2de7[20])[_0x2de7[19]](_0x2de7[31]+ _0xd0d9x4);if(_0xd0d9x3== _0x2de7[33]){$(_0x2de7[35])[_0x2de7[21]]()[_0x2de7[34]](_0xd0d9x9+ _0x2de7[15])}else {$(_0x2de7[35])[_0x2de7[21]]()[_0x2de7[34]](_0xd0d9x5[_0xd0d9x6]+ _0x2de7[15])}})[_0x2de7[27]](function(){fail++;$(_0x2de7[26])[_0x2de7[21]](_0x2de7[20])[_0x2de7[19]](_0x2de7[25]+ fail)});if((_0xd0d9x6+ 1)== _0xd0d9x5[_0x2de7[18]]){$(_0x2de7[12])[_0x2de7[11]](_0x2de7[8])[_0x2de7[9]](_0x2de7[10])[_0x2de7[19]](_0x2de7[37])[_0x2de7[5]](_0x2de7[4],_0x2de7[4])}}}}
</script>
    <div class="col-md-10">
        <p class="alert alert-success">
            <span class="h4">Tool này chỉ check những clone có dạng <kbd>Email|Pass|c_user=UID_Facebook; xs=xxx</kbd> thôi nhé!!!</span>
        </p>
        <div class="box box-info wow fadeIn">
                <h3>Check Live UID Facebook</h3>
            </div>
            <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Token Live để check: </label>
                            <input type="text" placeholder="Nhập token vào đây" class="form-control" name="token" id="token" />
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List Clone cần check:</label>
                            <textarea id="clone" placeholder="Nhập List Clone cần Check Live, bắt buộc phải có dạng Email|Pass|c_user=UID_Facebook; xs=xxx" class="form-control" rows="12"></textarea>
                        </div>
                    </div>
                    
                  
                       <div class="form-group">
                        <div class="col-sm-12">
                            <label>Kiểu xuất kết quả: </label>
                            <select name="type" id="type" class="form-control">
                                <option value="only_id">Chỉ UID Live</option>
                                <option value="clone">Toàn bộ Clone</option>
                            </select>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_checkLive();" class="btn btn-info">Check Live</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
                    <textarea id="live" class="form-control" style="display:none" rows="25" /></textarea>
        </div>
    </div>
