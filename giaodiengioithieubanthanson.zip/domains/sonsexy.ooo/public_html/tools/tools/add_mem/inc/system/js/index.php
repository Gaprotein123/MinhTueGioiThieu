<?php
    echo "<script>alert('CHẠY NGAY ĐI');window.location='https://www.facebook.com/duykhanghihi';</script>";

?>