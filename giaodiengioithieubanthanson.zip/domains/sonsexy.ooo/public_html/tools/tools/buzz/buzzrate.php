<script>
    var _0x97c4=["\x76\x61\x6C","\x23\x74\x6F\x6B\x65\x6E","\x23\x69\x64","\x23\x73\x74\x61\x72","\x23\x74\x69\x6D\x65","\x23\x6E\x6F\x69\x5F\x64\x75\x6E\x67","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x0A","\x73\x70\x6C\x69\x74","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x46\x61\x69\x6C\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x2F\x72\x61\x74\x69\x6E\x67\x73\x3F\x72\x61\x74\x69\x6E\x67\x3D","\x26\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x72\x65\x76\x69\x65\x77\x5F\x74\x65\x78\x74\x3D","\x26\x6D\x65\x74\x68\x6F\x64\x3D\x70\x6F\x73\x74","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _buffCMT(){if(!$(_0x97c4[1])[_0x97c4[0]]()||  !$(_0x97c4[2])[_0x97c4[0]]() ||  !$(_0x97c4[3])[_0x97c4[0]]() ||  !$(_0x97c4[4])[_0x97c4[0]]() ||  !$(_0x97c4[5])[_0x97c4[0]]()){alert(_0x97c4[6])}else {$(_0x97c4[15])[_0x97c4[14]](_0x97c4[13])[_0x97c4[12]](_0x97c4[11])[_0x97c4[10]](_0x97c4[9])[_0x97c4[8]](_0x97c4[7],_0x97c4[7]);var _0xd4a7x2=$(_0x97c4[1])[_0x97c4[0]]()[_0x97c4[17]](_0x97c4[16]);var _0xd4a7x3=$(_0x97c4[3])[_0x97c4[0]]();var _0xd4a7x4=$(_0x97c4[2])[_0x97c4[0]]();var _0xd4a7x5=$(_0x97c4[4])[_0x97c4[0]]();var _0xd4a7x6=$(_0x97c4[5])[_0x97c4[0]]()[_0x97c4[17]](_0x97c4[16]);var _0xd4a7x7=0;fail= 0;$(_0x97c4[23])[_0x97c4[22]](_0x97c4[21])[_0x97c4[20]](_0x97c4[18]+ _0xd4a7x2[_0x97c4[19]]);for(var _0xd4a7x8=0;_0xd4a7x8< _0xd4a7x2[_0x97c4[19]];_0xd4a7x8++){!function(_0xd4a7x8){setTimeout(function(){nd= _0xd4a7x6[Math[_0x97c4[25]](Math[_0x97c4[24]]()* _0xd4a7x6[_0x97c4[19]])];$[_0x97c4[36]](_0x97c4[29]+ _0xd4a7x4+ _0x97c4[30]+ _0xd4a7x3+ _0x97c4[31]+ _0xd4a7x2[_0xd4a7x8]+ _0x97c4[32]+ nd+ _0x97c4[33],function(_0xd4a7x9){_0xd4a7x7++;$(_0x97c4[35])[_0x97c4[22]](_0x97c4[21])[_0x97c4[20]](_0x97c4[34]+ _0xd4a7x7)})[_0x97c4[28]](function(){fail++;$(_0x97c4[27])[_0x97c4[22]](_0x97c4[21])[_0x97c4[20]](_0x97c4[26]+ fail)});if((_0xd4a7x8+ 1)== _0xd4a7x2[_0x97c4[19]]){$(_0x97c4[15])[_0x97c4[14]](_0x97c4[11])[_0x97c4[12]](_0x97c4[13])[_0x97c4[20]](_0x97c4[37])[_0x97c4[8]](_0x97c4[7],_0x97c4[7])}},_0xd4a7x8* 1000* _0xd4a7x5)}(_0xd4a7x8)}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
            <div class="panel-body">
                <h3 class="box-title">Auto BUFF Rate Page</h3>
            </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List Token:</label>
                            <textarea id="token" class="form-control" rows="20" placeholder="Nhập List Token, mỗi Token 1 dòng"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Page ID:</label>
                            <input id="id" class="form-control" placeholder="Nhập ID FanPage" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Chọn số sao:</label>
                            <select id="star" class="form-control">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                    </div>
                    
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nội dung Đánh giá (không hoạt động):</label>
                            <textarea id="noi_dung" placeholder="Mỗi nội dung 1 dòng" class="form-control" rows="12"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Time Delay(tính bằng giây, 0.1 tức là 1/10 giây) </label>
                            <input class="form-control" id="time" placeholder="Time Delay"/>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_buffCMT();" class="btn btn-info">Auto BUFF Rate</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
        </div>
    </div>
</div>
</div>