<script>
    var _0xaece=["\x76\x61\x6C","\x23\x74\x6F\x6B\x65\x6E","\x23\x69\x64","\x23\x74\x69\x6D\x65","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x0A","\x73\x70\x6C\x69\x74","\x23\x74\x79\x70\x65","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x52\x41\x4E\x44\x4F\x4D","\x4C\x49\x4B\x45","\x4C\x4F\x56\x45","\x48\x41\x48\x41","\x57\x4F\x57","\x53\x41\x44","\x41\x4E\x47\x52\x59","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x2F\x72\x65\x61\x63\x74\x69\x6F\x6E\x73\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x74\x79\x70\x65\x3D","\x26\x6D\x65\x74\x68\x6F\x64\x3D\x70\x6F\x73\x74","\x2F\x6C\x69\x6B\x65\x73\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _buffReaction(){if(!$(_0xaece[1])[_0xaece[0]]()||  !$(_0xaece[2])[_0xaece[0]]() ||  !$(_0xaece[3])[_0xaece[0]]()){alert(_0xaece[4])}else {$(_0xaece[13])[_0xaece[12]](_0xaece[11])[_0xaece[10]](_0xaece[9])[_0xaece[8]](_0xaece[7])[_0xaece[6]](_0xaece[5],_0xaece[5]);var _0x6f57x2=$(_0xaece[1])[_0xaece[0]]()[_0xaece[15]](_0xaece[14]);var _0x6f57x3=$(_0xaece[2])[_0xaece[0]]();var _0x6f57x4=$(_0xaece[3])[_0xaece[0]]();var _0x6f57x5;var _0x6f57x6=$(_0xaece[16])[_0xaece[0]]();var _0x6f57x7=0;fail= 0;$(_0xaece[22])[_0xaece[21]](_0xaece[20])[_0xaece[19]](_0xaece[17]+ _0x6f57x2[_0xaece[18]]);for(var _0x6f57x8=0;_0x6f57x8< _0x6f57x2[_0xaece[18]];_0x6f57x8++){!function(_0x6f57x8){setTimeout(function(){if(_0x6f57x6== _0xaece[23]){var _0x6f57x9=[_0xaece[24],_0xaece[25],_0xaece[26],_0xaece[27],_0xaece[28],_0xaece[29]];_0x6f57x5= _0x6f57x9[Math[_0xaece[31]](Math[_0xaece[30]]()* _0x6f57x9[_0xaece[18]])]}else {_0x6f57x5= _0x6f57x6};var _0x6f57xa=_0xaece[32]+ _0x6f57x3+ _0xaece[33]+ _0x6f57x2[_0x6f57x8]+ _0xaece[34]+ _0x6f57x5+ _0xaece[35];if(_0x6f57x6== _0xaece[24]){_0x6f57xa= _0xaece[32]+ _0x6f57x3+ _0xaece[36]+ _0x6f57x2[_0x6f57x8]+ _0xaece[35]};$[_0xaece[39]](_0x6f57xa,function(_0x6f57xb){_0x6f57x7++;$(_0xaece[38])[_0xaece[21]](_0xaece[20])[_0xaece[19]](_0xaece[37]+ _0x6f57x7)});if((_0x6f57x8+ 1)== _0x6f57x2[_0xaece[18]]){$(_0xaece[13])[_0xaece[12]](_0xaece[9])[_0xaece[10]](_0xaece[11])[_0xaece[19]](_0xaece[40])[_0xaece[6]](_0xaece[5],_0xaece[5])}},_0x6f57x8* 1000* _0x6f57x4)}(_0x6f57x8)}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
            <div class="panel-body">
                <h3 class="box-title">Auto BUFF Reaction</h3>
            </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List Token:</label>
                            <textarea id="token" class="form-control" rows="20" placeholder="Nhập List Token, mỗi Token 1 dòng"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Post ID (Cảm xúc khác LIKE thì PHẢI nhập postId dạng userID_postID nhé ):</label>
                            <input id="id" class="form-control" placeholder="Nhập Post ID ( Có thể là ID bài viết, ảnh(trang cá nhân, page, nhóm công khai, sự kiện.. ). Hoặc ID của FanPage để Like Pge" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Chọn loại cảm xúc:</label>
                            <select name="type" id="type" class="form-control">
                                <option value="RANDOM">NGẪU NHIÊN</option>
                                <option value="LIKE">LIKE</option>
                                <option value="LOVE">LOVE</option>
                                <option value="HAHA">HAHA</option>
                                <option value="WOW">WOW</option>
                                <option value="SAD">SAD</option>
                                <option value="ANGRY">ANGRY</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Time Delay(tính bằng giây, 0.1 tức là 1/10 giây) </label>
                            <input class="form-control" id="time" placeholder="Time Delay"/>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_buffReaction();" class="btn btn-info">Auto BUFF Reaction</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
        </div>
    </div>
</div>
</div>