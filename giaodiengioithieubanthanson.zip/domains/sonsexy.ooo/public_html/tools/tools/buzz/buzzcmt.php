<script>
    var _0x6981=["\x76\x61\x6C","\x23\x74\x6F\x6B\x65\x6E","\x23\x69\x64","\x23\x74\x69\x6D\x65","\x23\x6E\x6F\x69\x5F\x64\x75\x6E\x67","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x0A","\x73\x70\x6C\x69\x74","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x46\x61\x69\x6C\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x2F\x63\x6F\x6D\x6D\x65\x6E\x74\x73\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x6D\x65\x73\x73\x61\x67\x65\x3D","\x26\x6D\x65\x74\x68\x6F\x64\x3D\x70\x6F\x73\x74","\x53\x75\x63\x63\x65\x73\x73\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _buffCMT(){if(!$(_0x6981[1])[_0x6981[0]]()||  !$(_0x6981[2])[_0x6981[0]]() ||  !$(_0x6981[3])[_0x6981[0]]() ||  !$(_0x6981[4])[_0x6981[0]]()){alert(_0x6981[5])}else {$(_0x6981[14])[_0x6981[13]](_0x6981[12])[_0x6981[11]](_0x6981[10])[_0x6981[9]](_0x6981[8])[_0x6981[7]](_0x6981[6],_0x6981[6]);var _0x4e87x2=$(_0x6981[1])[_0x6981[0]]()[_0x6981[16]](_0x6981[15]);var _0x4e87x3=$(_0x6981[2])[_0x6981[0]]();var _0x4e87x4=$(_0x6981[3])[_0x6981[0]]();var _0x4e87x5=$(_0x6981[4])[_0x6981[0]]()[_0x6981[16]](_0x6981[15]);var _0x4e87x6=0;fail= 0;$(_0x6981[22])[_0x6981[21]](_0x6981[20])[_0x6981[19]](_0x6981[17]+ _0x4e87x2[_0x6981[18]]);for(var _0x4e87x7=0;_0x4e87x7< _0x4e87x2[_0x6981[18]];_0x4e87x7++){!function(_0x4e87x7){setTimeout(function(){nd= _0x4e87x5[Math[_0x6981[24]](Math[_0x6981[23]]()* _0x4e87x5[_0x6981[18]])];$[_0x6981[34]](_0x6981[28]+ _0x4e87x3+ _0x6981[29]+ _0x4e87x2[_0x4e87x7]+ _0x6981[30]+ encodeURIComponent(nd)+ _0x6981[31],function(_0x4e87x8){_0x4e87x6++;$(_0x6981[33])[_0x6981[21]](_0x6981[20])[_0x6981[19]](_0x6981[32]+ _0x4e87x6)})[_0x6981[27]](function(){fail++;$(_0x6981[26])[_0x6981[21]](_0x6981[20])[_0x6981[19]](_0x6981[25]+ fail)});if((_0x4e87x7+ 1)== _0x4e87x2[_0x6981[18]]){$(_0x6981[14])[_0x6981[13]](_0x6981[10])[_0x6981[11]](_0x6981[12])[_0x6981[19]](_0x6981[35])[_0x6981[7]](_0x6981[6],_0x6981[6])}},_0x4e87x7* 1000* _0x4e87x4)}(_0x4e87x7)}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
                <h3 class="box-title">Auto BUFF CMT</h3>
            </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List Token:</label>
                            <textarea id="token" class="form-control" rows="20" placeholder="Nhập List Token, mỗi Token 1 dòng"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Post ID:</label>
                            <input id="id" class="form-control" placeholder="Nhập Post ID ( Có thể là ID bài viết, ảnh(trang cá nhân, page, nhóm công khai, sự kiện.. )" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nội dung CMT:</label>
                            <textarea id="noi_dung" placeholder="Mỗi CMT 1 dòng" class="form-control" rows="12"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Time Delay(tính bằng giây, 0.1 tức là 1/10 giây) </label>
                            <input class="form-control" id="time" placeholder="Time Delay"/>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_buffCMT();" class="btn btn-info">Auto BUFF CMT</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
        </div>
    </div>
</div>
</div>