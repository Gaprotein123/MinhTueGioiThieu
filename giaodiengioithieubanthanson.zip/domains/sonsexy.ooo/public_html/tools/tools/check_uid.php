<script>
    var _0xdd83=["\x76\x61\x6C","\x23\x6C\x69\x73\x74","\x23\x74\x6F\x6B\x65\x6E","\x4E\x68\u1EAD\x70\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67\x20\x74\x69\x6E","\x64\x69\x73\x61\x62\x6C\x65\x64","\x61\x74\x74\x72","\x3C\x69\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x61\x20\x66\x61\x2D\x73\x70\x69\x6E\x6E\x65\x72\x20\x66\x61\x2D\x73\x70\x69\x6E\x22\x3E\x3C\x2F\x69\x3E\x20\u0110\x61\x6E\x67\x20\x78\u1EED\x20\x6C\xED\x2E\x2E","\x68\x74\x6D\x6C","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x77\x61\x72\x6E\x69\x6E\x67","\x61\x64\x64\x43\x6C\x61\x73\x73","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x69\x6E\x66\x6F","\x72\x65\x6D\x6F\x76\x65\x43\x6C\x61\x73\x73","\x23\x73\x74\x61\x72\x74","\x23\x74\x79\x70\x65","\x74\x72\x69\x6D","\x23\x73\x6C\x69\x63\x65","\x73\x70\x6C\x69\x74","","\x0A","\x54\x6F\x74\x61\x6C\x3A\x20","\x6C\x65\x6E\x67\x74\x68","\x74\x65\x78\x74","\x73\x6C\x6F\x77","\x66\x61\x64\x65\x49\x6E","\x23\x74\x6F\x74\x61\x6C","\x44\x69\x65\x3A\x20","\x23\x66\x61\x69\x6C","\x66\x61\x69\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x72\x61\x70\x68\x2E\x66\x62\x2E\x6D\x65\x2F","\x3F\x61\x63\x63\x65\x73\x73\x5F\x74\x6F\x6B\x65\x6E\x3D","\x26\x66\x69\x65\x6C\x64\x73\x3D\x69\x64\x26\x6D\x65\x74\x68\x6F\x64\x3D\x67\x65\x74","\x4C\x69\x76\x65\x3A\x20","\x23\x73\x75\x63\x63\x65\x73\x73","\x6F\x6E\x6C\x79\x5F\x69\x64","\x61\x70\x70\x65\x6E\x64","\x23\x6C\x69\x76\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x2F\x77\x77\x77\x2E\x66\x61\x63\x65\x62\x6F\x6F\x6B\x2E\x63\x6F\x6D\x2F","\x67\x65\x74\x4A\x53\x4F\x4E","\x48\x6F\xE0\x6E\x20\x74\x68\xE0\x6E\x68"];function _checkLive(){if(!$(_0xdd83[1])[_0xdd83[0]]()||  !$(_0xdd83[2])[_0xdd83[0]]()){alert(_0xdd83[3])}else {$(_0xdd83[12])[_0xdd83[11]](_0xdd83[10])[_0xdd83[9]](_0xdd83[8])[_0xdd83[7]](_0xdd83[6])[_0xdd83[5]](_0xdd83[4],_0xdd83[4]);var _0xa341x2=$(_0xdd83[2])[_0xdd83[0]]();var _0xa341x3=$(_0xdd83[13])[_0xdd83[0]]();var _0xa341x4=$(_0xdd83[15])[_0xdd83[0]]()[_0xdd83[14]]();var _0xa341x5=$(_0xdd83[1])[_0xdd83[0]]()[_0xdd83[16]](_0xa341x4);if(_0xa341x4== _0xdd83[17]){var _0xa341x5=$(_0xdd83[1])[_0xdd83[0]]()[_0xdd83[14]]()[_0xdd83[16]](_0xdd83[18])};var _0xa341x6=0;fail= 0;$(_0xdd83[24])[_0xdd83[23]](_0xdd83[22])[_0xdd83[21]](_0xdd83[19]+ _0xa341x5[_0xdd83[20]]);for(let _0xa341x7=0;_0xa341x7< _0xa341x5[_0xdd83[20]];_0xa341x7++){$[_0xdd83[37]](_0xdd83[28]+ _0xa341x5[_0xa341x7]+ _0xdd83[29]+ _0xa341x2+ _0xdd83[30],function(_0xa341x8){_0xa341x6++;$(_0xdd83[32])[_0xdd83[23]](_0xdd83[22])[_0xdd83[21]](_0xdd83[31]+ _0xa341x6);if(_0xa341x3== _0xdd83[33]){$(_0xdd83[35])[_0xdd83[23]]()[_0xdd83[34]](_0xa341x5[_0xa341x7]+ _0xdd83[18])}else {$(_0xdd83[35])[_0xdd83[23]]()[_0xdd83[34]](_0xdd83[36]+ _0xa341x5[_0xa341x7]+ _0xdd83[18])}})[_0xdd83[27]](function(){fail++;$(_0xdd83[26])[_0xdd83[23]](_0xdd83[22])[_0xdd83[21]](_0xdd83[25]+ fail)});if((_0xa341x7+ 1)== _0xa341x5[_0xdd83[20]]){$(_0xdd83[12])[_0xdd83[11]](_0xdd83[8])[_0xdd83[9]](_0xdd83[10])[_0xdd83[21]](_0xdd83[38])[_0xdd83[5]](_0xdd83[4],_0xdd83[4])}}}}
</script>
    <div class="col-md-10">
        <div class="box box-info wow fadeIn">
                <h3>Check Live UID Facebook</h3>
            </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập Token Live để check: </label>
                            <input type="text" placeholder="Nhập token vào đây" class="form-control" name="token" id="token" />
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Nhập List UID cần check:</label>
                            <textarea id="list" placeholder="Nhập List UID cần Check Live" class="form-control" rows="12"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label>Phân cách bởi dấu (nếu để trống ô dưới sẽ là dấu xuống dòng): </label>
                            <input type="text" placeholder="Nhập dấu phân cách từng UID, để trống sẽ là dấu xuống  dòng!" class="form-control" name="slice" id="slice" />
                        </div>
                    </div>
                       <div class="form-group">
                        <div class="col-sm-12">
                            <label>Kiểu xuất kết quả: </label>
                            <select name="type" id="type" class="form-control">
                                <option value="only_id">Chỉ UID Live</option>
                                <option value="profile">Toàn bộ Link Profile</option>
                            </select>
                        </div>
                    </div>
                    <div class="box-footer" style="text-align:center;margin-top:10px">
                        <button type="button" id="start" name="start" onclick="_checkLive();" class="btn btn-info">Check Live</button>
                        <button id="total" class="btn btn-default" style="display:none"></button>
                        <button id="success" class="btn btn-success" style="display:none"></button>
                        <button id="fail" class="btn btn-danger" style="display:none"></button>
                    </div>
                    <textarea id="live" class="form-control" style="display:none" rows="25" /></textarea>
                    
        </div>
    </div>
